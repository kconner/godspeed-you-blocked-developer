"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const gateway = require("./APIGatewayAdapter");
const dynamo = require("./DynamoDBAdapter");
exports.getState = (event, context, callback) => {
    try {
        const input = tryInputFromRequest(process.env, event);
        new aws_sdk_1.DynamoDB().getItem(input, (error, output) => {
            const response = gateway.responseForGetItem(error, output, stateFromItem);
            callback(null, response);
        });
    }
    catch (errorResponse) {
        callback(null, errorResponse);
    }
};
const tryInputFromRequest = (env, event) => dynamo.inputForGetItem(gateway.tryEnvironmentVariable(process.env, 'GYBD_TABLE_STATES'), gateway.tryPathParameter(event, 'stateID'));
const stateFromItem = (item) => ({
    id: dynamo.stringFromAttribute(item, 'id'),
    value: dynamo.mapFromAttribute(item, 'value')
});
//# sourceMappingURL=getState.js.map