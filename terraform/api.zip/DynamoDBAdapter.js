"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inputForGetItem = (tableName, id) => ({
    TableName: tableName,
    Key: {
        id: { S: id }
    }
});
exports.stringFromAttribute = (item, name) => attributeFromItem(item, name).S || '';
exports.mapFromAttribute = (item, name) => attributeFromItem(item, name).M || {};
const attributeFromItem = (item, name) => item[name] || {};
//# sourceMappingURL=DynamoDBAdapter.js.map