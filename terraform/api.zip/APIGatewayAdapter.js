"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tryEnvironmentVariable = (env, name) => {
    const value = env[name];
    if (!value) {
        throw response(500, { message: `Missing environment variable ${name}` });
    }
    return value;
};
exports.tryPathParameter = (event, name) => {
    const pathParameters = event.pathParameters || {};
    const value = pathParameters[name];
    if (!value) {
        throw response(400, { message: `Missing path parameter ${name}` });
    }
    return value;
};
exports.responseForGetItem = (error, output, mapItem) => {
    if (error) {
        return response(500, { message: error.message, underlying: error });
    }
    const item = output.Item;
    if (!item) {
        return response(404, { message: 'No such item' });
    }
    return response(200, mapItem(item));
};
const response = (statusCode, body) => ({
    statusCode,
    headers: {
        'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify(body)
});
//# sourceMappingURL=APIGatewayAdapter.js.map